<?php

	if($_SERVER['REQUEST_METHOD']=='POST'){
		
		//Getting values
		$first_Name = $_POST['fname'];
		$middle_Name = $_POST['mname'];
		$last_Name = $_POST['lname'];
		$email = $_POST['email'];
		$password = $_POST['password'];
		$gender = $_POST['gender'];
		$mobile_No = $_POST['mno'];
		
		$key_value = md5($password);
            
                
                $iv = mcrypt_create_iv(mcrypt_get_iv_size(MCRYPT_RIJNDAEL_128, MCRYPT_MODE_CBC),MCRYPT_DEV_URANDOM);
                

		$encrypted = base64_encode($iv.mcrypt_encrypt(MCRYPT_RIJNDAEL_128,hash('sha256', $key_value, true),$password,MCRYPT_MODE_CBC,$iv));
                
                
		

		
                
                
                   
                   
		$check_email = "select email from tbl_users where email = '$email'";
                
                
                //Creating an sql query
		$sql = "INSERT INTO tbl_users (fname,mname,lname,email,password,pass_key,iv,gender,mno) VALUES ('$first_Name','$middle_Name','$last_Name','$email','$encrypted','$key_value','$iv','$gender','$mobile_No')";
		
                
		require 'DBConnect.php';
                
                
                if (mysqli_query($con, $sql)) {
                
                    
                                $to      = $email; // Send email to our user
				$subject = 'Signup | Verification'; // Give the email a subject 
				$message = "
				 
				Thanks for signing up!.<br>
				Your account has been created, you can login with the following credentials after you have activated your account by pressing the url below.<br><br>
				 
				------------------------<br>
				Username: '$email'<br>
				Password: '$password'<br>
				------------------------<br>
				 <br>
				Please click this link to activate your account:<br>
				http://localhost/QuizApplication/verify.php?email=$email&key_value=$key_value.
				 
				"; // Our message above including the link
									 
				

                               require_once('phpmailer/PHPMailerAutoload.php');
	
	
	          $mail             = new PHPMailer();
                  $body             = $message;
                  $mail->IsSMTP();
                  $mail->Host       = "smtp.gmail.com";                  
                  $mail->SMTPAuth   = true;
                  $mail->Host       = "smtp.gmail.com";
                  $mail->Port       = 587;
                  $mail->Username   = 'dnsudhir@gmail.com';
                  $mail->Password   = '$dNs$441419$';
                  $mail->SMTPSecure = 'tls';
                  $mail->SetFrom('ucss.saifabad@gmail.com', 'Admin');
                  $mail->AddReplyTo('ucss.saifabad@gmail.com','Admin');
                  $mail->Subject    = $subject;
                  $mail->AltBody    = "To view the message, please use an HTML compatible email viewer!";
                  $mail->MsgHTML($body);
                  $address = $to;
                  $mail->AddAddress($address);
                  $mail->Send();
                 // echo $mail->ErrorInfo;
                     
                    
                    
                    
                        echo "Registration Successful";
                
                }else{
                    
                    
                        echo "Email Already Registered";
                    
                }
                
            //Closing the database 
		mysqli_close($con);
	}
?>









