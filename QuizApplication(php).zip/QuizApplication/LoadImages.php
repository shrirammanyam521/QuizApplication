<?php
	require_once('DBConnect.php');
	
	$sql = "select image_url from subject_thumbnails";
	
	$res = mysqli_query($con,$sql);
	
	$result = array();
	
	while($row = mysqli_fetch_array($res)){
		array_push($result,array('url'=>$row['image_url']));
	}
	
	echo json_encode(array("result"=>$result));
	
	mysqli_close($con);

