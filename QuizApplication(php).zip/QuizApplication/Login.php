<?php


	if($_SERVER['REQUEST_METHOD']=='POST'){
		
		//Getting values
		$lusername = $_POST['email'];
		$lpassword = $_POST['password'];
		$key_value = md5($lpassword);
		
                
               		
		
		//Creating an sql query
		$sql = "select status from tbl_users where email = '$lusername'";
		
		//Importing our db connection script
		require 'DBConnect.php';
		
		$result = mysqli_query($con,$sql);
		
		//Executing query to database
		if($result){
		  if(mysqli_num_rows($result) > 0)
		    {
                               
				$row = mysqli_fetch_array($result);
                                if($row['status'] == "Active"){
				echo "Login Successful";
                               }
                               else
                               {
                                 echo "Verify Email To Login";
                               }
		    }
		
		  else
		  {
			echo 'User Not Registered';
		  }
		}
		//Closing the database 
		mysqli_close($con);
                
	}
	
        ?>

