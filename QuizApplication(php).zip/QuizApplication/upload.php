<?php

 if($_SERVER['REQUEST_METHOD'] == 'POST'){
    
    
$name = $_FILES["uploaded_file"]["name"];
$email = $_POST["email"];



//$size = $_FILES['file']['size']
//$type = $_FILES['file']['type']

$tmp_name = $_FILES['uploaded_file']['tmp_name'];
$error = $_FILES['uploaded_file']['error'];

    $location = 'upload/';
    $path = "http://localhost/QuizApplication/".$location.$name;
   $sql = "insert into upload_files(path,email) values('$path','$email')";


    if (isset ($name)) 
    {

        if (!empty($name)) 
        {
    

    

                if  (move_uploaded_file($tmp_name, $location.$name))
                {
            

                        require 'DBConnect.php';

                            if (mysqli_query($con, $sql)) 
                            {
                            

                                echo "Success";   
                                

                            }


                }

        } else
        {
        
          echo 'Fail';
        }
    }
}
?>



<html>
<body>

<form action="upload.php" method="post" enctype="multipart/form-data">
    Select image to upload:
    <input type="file" name="uploaded_file" id="fileToUpload">
    <input type="text" name="email">
    <input type="submit" value="Upload Image" name="submit">
</form>

</body>
</html>