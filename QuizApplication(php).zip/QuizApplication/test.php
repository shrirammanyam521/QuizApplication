<?php
  
       if($_SERVER['REQUEST_METHOD'] == 'POST')
       {
               $email = $_POST['email'];
               $password = $_POST['password'];
               

   

              $key_value = 'e10adc3949ba59abbe56e057f20f883e';
              $encrypted_string = 'Dp3LmdMHw8SJMvWkQlZNP/JoN';

       
            $data = base64_decode($encrypted_string);
           $iv = substr($data, 0, mcrypt_get_iv_size(MCRYPT_RIJNDAEL_128, MCRYPT_MODE_CBC));
           $decrypted_string =rtrim(mcrypt_decrypt(MCRYPT_RIJNDAEL_128,hash('sha256', $key_value, true),substr($data, mcrypt_get_iv_size(MCRYPT_RIJNDAEL_128, MCRYPT_MODE_CBC)),MCRYPT_MODE_CBC,$iv),"\0");
           
           echo $decrypted_string;
               


     }


 ?>
 
 <html>
<body>

<form action="test.php" method="post">
   
    <input type="text" name="email" >
    <input type="text" name="password" >
    <input type="submit" name="submit">
</form>

</body>
</html>