<?php

if($_SERVER['REQUEST_METHOD']=='POST'){
    
    
    
    $email = $_POST['email'];
    
    
    
    
    $sql = "select * from tbl_users where email = '$email'";
    
    require 'DBConnect.php';
    
    $result = mysqli_query($con, $sql);
    
    if($result)
         {
           $row = mysqli_fetch_array($result);
           $key_value = $row['pass_key'];
           
           
           
           $encrypted_string = $row['password'];
           
           
           $data = base64_decode($encrypted_string);
           $iv = substr($data, 0, mcrypt_get_iv_size(MCRYPT_RIJNDAEL_128, MCRYPT_MODE_CBC));
           $decrypted_string =rtrim(mcrypt_decrypt(MCRYPT_RIJNDAEL_128,hash('sha256', $key_value, true),substr($data, mcrypt_get_iv_size(MCRYPT_RIJNDAEL_128, MCRYPT_MODE_CBC)),MCRYPT_MODE_CBC,$iv),"\0");
           
           
           
        
                
                    
                                $to      = $email; // Send email to our user
				$subject = 'Forgot | Password'; // Give the email a subject 
				$message = "
				 
				You have requested for Your Password!.<br>
				Following are you Login Credentials in to the app.<br><br>
				 
				------------------------<br>
				Username: '$email'<br>
				Password: '$decrypted_string'<br>
				------------------------<br>
				 <br>
				
				 
				"; // Our message above including the link
									 
				

                               require_once('phpmailer/PHPMailerAutoload.php');
	
	
	          $mail             = new PHPMailer();
                  $body             = $message;
                  $mail->IsSMTP();
                  $mail->Host       = "smtp.gmail.com";                  
                  $mail->SMTPAuth   = true;
                  $mail->Host       = "smtp.gmail.com";
                  $mail->Port       = 587;
                  $mail->Username   = 'dnsudhir@gmail.com';
                  $mail->Password   = '$dNs$441419$';
                  $mail->SMTPSecure = 'tls';
                  $mail->SetFrom('ucss.saifabad@gmail.com', 'Admin');
                  $mail->AddReplyTo('ucss.saifabad@gmail.com','Admin');
                  $mail->Subject    = $subject;
                  $mail->AltBody    = "To view the message, please use an HTML compatible email viewer!";
                  $mail->MsgHTML($body);
                  $address = $to;
                  $mail->AddAddress($address);
                  $mail->Send();
                 // echo $mail->ErrorInfo;
                     
                    
                    
                    
                        echo "Email Sent Successfully";
                
                }else{
                    
                    
                        echo "Email Not Registered";
                    
                }
                
            //Closing the database 
		mysqli_close($con);
    
    
    
}

?>



