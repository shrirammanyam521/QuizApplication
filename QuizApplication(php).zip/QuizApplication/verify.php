<?php

       
            
        $email = $_GET['email'];
	$key_value = $_GET['key_value'];
	    
    
	
	require 'DBConnect.php';
	
	$sql = "update tbl_users set status = 'Active' where email = '$email'";
	
	if(mysqli_query($con,$sql))
	{
		
		echo "Your Account is Active Now <br>you can successfully login in to the app with your credentials";
	}
	else
	{
			echo "Verification Failed";
	}
	

        mysqli_close($con);






















?>