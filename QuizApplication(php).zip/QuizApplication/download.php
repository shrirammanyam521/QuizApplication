<?php

$email = $_GET["email"];;


$sql = "select path from upload_files where email= '$email'";

require 'DBConnect.php';
$result = mysqli_query($con, $sql);

$update = 0;

echo "<h3>Download Files For: $email</h3>";


if($result){
    
    
            while($row =mysqli_fetch_array($result))
         {

               
                $update++;
                $link = $row['path'];
                $fname = substr($link,40,-4);
                echo "$update. <a href=$link>$fname</a><br>";
               
         }
         
         
    
    
}

mysqli_close($con);




?>



