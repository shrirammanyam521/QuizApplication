<!DOCTYPE html>
<!--
To change this license header, choose License Headers in Project Properties.
To change this template file, choose Tools | Templates
and open the template in the editor.
-->
<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <?php
        
        $link = mysqli_connect("localhost", "root", "", "quizdb");

/* check connection */
if (mysqli_connect_errno()) {
    printf("Connect failed: %s\n", mysqli_connect_error());
    exit();
}

/* Create table doesn't return a resultset */


/* Select queries return a resultset */
if ($result = mysqli_query($link, "SELECT * FROM questions")) {
    printf("Select returned %d rows.\n", mysqli_num_rows($result));

   
    
    
    /* free result set */
    mysqli_free_result($result);
}




mysqli_close($link);
        
        
        ?>
    </body>
</html>
