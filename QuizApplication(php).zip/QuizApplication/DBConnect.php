<?php

define('host','localhost');
define('username','root');
define('password','');
define('database_name','quizdb');

$con = mysqli_connect(host, username, password, database_name) or die('Unable To Connect');


